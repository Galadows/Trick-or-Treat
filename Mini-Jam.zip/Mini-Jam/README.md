# Mini-Jam
Little video-game project for the Mini-Jam 66
